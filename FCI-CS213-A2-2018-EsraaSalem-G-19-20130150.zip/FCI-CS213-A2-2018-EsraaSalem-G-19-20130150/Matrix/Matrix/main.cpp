// Course:  CS213 - Programming II  - 2018
// Title:   Assignment 2 - Task 1 - Problem 2
// Program: CS213-2018-A2-T1-P2
// Author:  Sherif Mohamed AbdelGhaffar Mohamed / Hala / Mohammed El Deeb

#include <iostream>
#include <iomanip>
#include <cassert>
#include <valarray>
#include <Matrix.h>

using namespace std;
int main()
{
  int data1 [] = {1,2,3,4,5,6,7,8};
  int data2 [] = {13,233,3,4,5,6};
  int data4 [] = {10,100,10,100,10,100,10,100};
  int Scalarr = 7 ;
  matrix mat1, mat2, mat4 ;
  createMatrix (4, 2, data1, mat1);
  createMatrix (2, 3, data2, mat2);
  createMatrix (4, 2, data4, mat4);

// The next code will not work until complete functions
  cout << mat1 << endl;
  cout << mat2 << endl;
  cout << mat4 << endl;

  ++mat1;
  cout << mat1 << endl;

  mat1+= mat3 += mat3;
  cout << mat1 << endl;
  cout << mat2 << endl;
  cout << mat3 << endl;

  // .......

  return 0;

}
