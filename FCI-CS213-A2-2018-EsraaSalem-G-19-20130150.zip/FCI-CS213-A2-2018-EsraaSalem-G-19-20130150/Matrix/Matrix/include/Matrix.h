#ifndef MATRIX_H
#define MATRIX

#include <iostream>

using namespace std;

class Matrix
{

 private:
// A structure to store a matrix
  valarray<int> data ;       //valarray that will simulate matrix
  int row, col ;


public:

/*
   // part 1
    void createMatrix (int row, int col, int num[], Matrix& mat);
     Matrix operator+  (Matrix mat1, Matrix mat2); // Add if same dimensions
Matrix operator-  (Matrix mat1, Matrix mat2); // Sub if same dimensions
Matrix operator*  (Matrix mat1, Matrix mat2); // Multi if col1 == row2
Matrix operator+  (Matrix mat1, int scalar);  // Add a scalar
Matrix operator-  (Matrix mat1, int scalar);  // Subtract a scalar
Matrix operator*  (Matrix mat1, int scalar);  // Multiple by scalar

*/
/////////////////////////////////////////////////////////////////////////////////////////////////
// part 2
// Student #2 with the middle ID (e.g., 20170082)
// The last operator >> takes an istream and a matrix

//and return the
// the same istream so it is possible to cascade input

//like
// cin >> matrix1 >> matrix2 << endl;


Matrix operator+= (Matrix& mat1, Matrix mat2); // mat1

//changes & return new+
//matrix with the sum


Matrix operator-= (Matrix& mat1, Matrix mat2); // mat1
// changes + return new matrix with difference


Matrix operator+= (Matrix& mat, int scalar);   // change mat & return new matrix
Matrix operator-= (Matrix& mat, int scalar);   // change mat & return new matrix
void   operator++ (Matrix& mat);   	// Add 1 to each element ++mat
void   operator-- (Matrix& mat);    	// Sub 1 from each element --mat

istream& operator>> (istream& in, Matrix& mat);
// Input matrix like this (dim 2 x 3) cin >> 2 3 4 6 8 9 12 123
       // and return istream to allow cascading input


       /////////////////////////////////////////////////////////////////////////////////////
/*
// part 3
  //Student #3 with the biggest ID (e.g., 20170089)
ostream& operator<< (ostream& out, Matrix mat);
       	// Print matrix  as follows (2 x 3)
        // 4	 6 	  8
	       // and return ostream to cascade printing
           // 9	12  	123
bool   operator== (Matrix mat1, Matrix mat2);	// True if identical

bool   operator!= (Matrix mat1, Matrix mat2); 	// True if not same
bool   isSquare   (Matrix mat);  // True if square matrix
bool   isSymetric (Matrix mat);  // True if square and symmetric
bool   isIdentity (Matrix mat);  // True if square and identity
Matrix transpose(Matrix mat);    // Return new matrix with the transpose

//__________________________________________




     friend ostream& operator<<(ostream& os , const Matrix & n);
     friend istream& operator>>(istream& is , Matrix & n);
     void operator = (Matrix n) ;
     void operator=(Matrix n); // For Assign The Number
     Matrix();
   // Matrix(string s);

};

*/
#endif // BIGDECIMALINT_H
