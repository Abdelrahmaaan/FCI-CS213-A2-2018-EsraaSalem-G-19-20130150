#include <iostream>
#include <iomanip>
#include <valarray>
using namespace std;

// A structure to store a matrix
struct matrix
{
  valarray<int> data ;       //valarray that will simulate matrix
  int row, col;

};
void createMatrix (int row, int col, int num[], matrix& mat) {
  mat.row = row;
  mat.col = col;
  mat.data.resize (row * col);
  for (int i = 0; i < row * col; i++)
    mat.data [i] = num [i];
}


matrix operator+= (matrix& mat1, matrix mat2)
{

    for (int i = 0; i < mat1.row * mat1.col; i++)
        mat1.data [i] += mat2.data [i];

    return mat1 ;
}

matrix operator-= (matrix& mat1, matrix mat2)
{

    for (int i = 0; i < mat1.row * mat1.col; i++)
        mat1.data [i] += mat2.data [i];

    return mat1 ;
}

matrix operator+= (matrix& mat, int scalar)
{
    for (int i = 0; i < mat.row * mat.col; i++)
        mat.data [i] += scalar;

    return mat ;
}

matrix operator-= (matrix& mat, int scalar)
{
    for (int i = 0; i < mat.row * mat.col; i++)
        mat.data [i] -= scalar;

    return mat ;

}
void   operator++ (matrix& mat)
{

    for (int i = 0; i < mat.row * mat.col; i++)
        mat.data [i] ++;

}

void   operator-- (matrix& mat)
{

    for (int i = 0; i < mat.row * mat.col; i++)
        mat.data [i] --;

}

istream& operator>> (istream& in, matrix& mat)
{
    int row, col;
    in >> row >> col;
    mat.row = row;
    mat.col = col;
    mat.data.resize (row * col);
    for (int i = 0; i < row * col; i++)
        in >> mat.data [i] ;
}
..........................
......................
....................
..........................
...........................





